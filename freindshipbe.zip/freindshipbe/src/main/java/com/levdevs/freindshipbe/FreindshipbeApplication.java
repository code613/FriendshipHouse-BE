package com.levdevs.freindshipbe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FreindshipbeApplication {

	public static void main(String[] args) {
		SpringApplication.run(FreindshipbeApplication.class, args);
	}

}
